from tinyec import registry
from Crypto.Cipher import AES
import hashlib, secrets, binascii
import os
import binascii
from x25519 import base_point_mult, multscalar, bytes_to_int
from timeit import default_timer as timer

start = timer()
#Bob and Alice Pritave Key
a = os.urandom(32)
b = os.urandom(32)

#Bob and Alice public Key
a_pub = base_point_mult(a)
b_pub = base_point_mult(b)

x = os.urandom(32)
y = os.urandom(32)

#Bob and Alice shared secret Key
Bob_send = multscalar(y, a_pub) # (y) aG
Bob_send = multscalar(b, Bob_send) # (yb) aG


Alice_send = multscalar(x, b_pub) # (x) bG
Alice_send = multscalar(a, Alice_send) # (xa) bG

#Bob and Alice Shared Secret key
k_a = multscalar(x, Bob_send) # x (yb) aG
k_b = multscalar(y, Alice_send) # y ( xa) bG

end = timer()


print (f"\n\nThe private key 'Bob' is (b):\t{bytes_to_int(b)}")
print (f"The private key 'Alice' is (a): \t{bytes_to_int(a)}")

print ("\n\nThe public key 'Bob' is (bG):\t",binascii.hexlify(b_pub.encode()))
print ("The public key 'Alice' is (aG):\t",binascii.hexlify(a_pub.encode()))

print ("\n\nThe Shared secret key 'Bob' is (b)aG:\t",binascii.hexlify(k_b.encode()))
print ("The Shared secret key 'Alice' is (a)bG:\t",binascii.hexlify(k_a.encode()))
print('\n\n Time taken to execute the Shared Key: ', end-start)

#Shared secret Key
print ("\n\nThe Shared secret key is:\t",binascii.hexlify(k_b.encode()))

def encrypt_AES_GCM(msg, secretKey):
    aesCipher = AES.new(secretKey, AES.MODE_GCM)
    ciphertext, authTag = aesCipher.encrypt_and_digest(msg)
    return (ciphertext, aesCipher.nonce, authTag)

def decrypt_AES_GCM(ciphertext, nonce, authTag, secretKey):
    aesCipher = AES.new(secretKey, AES.MODE_GCM, nonce)
    plaintext = aesCipher.decrypt_and_verify(ciphertext, authTag)
    return plaintext

def ecc_point_to_256_bit_key(point):
    sha = hashlib.sha256(int.to_bytes(point.x, 32, 'big'))
    sha.update(int.to_bytes(point.y, 32, 'big'))
    return sha.digest()

curve = registry.get_curve('brainpoolP256r1')
def encrypt_ECC(msg, pubKey):
    ciphertextPrivKey = secrets.randbelow(curve.field.n)
    sharedECCKey = ciphertextPrivKey * pubKey
    secretKey = ecc_point_to_256_bit_key(sharedECCKey)
    ciphertext, nonce, authTag = encrypt_AES_GCM(msg, secretKey)
    ciphertextPubKey = ciphertextPrivKey * curve.g
    return (ciphertext, nonce, authTag, ciphertextPubKey)

def decrypt_ECC(encryptedMsg, privKey):
    (ciphertext, nonce, authTag, ciphertextPubKey) = encryptedMsg
    sharedECCKey = privKey * ciphertextPubKey
    secretKey = ecc_point_to_256_bit_key(sharedECCKey)
    plaintext = decrypt_AES_GCM(ciphertext, nonce, authTag, secretKey)
    return plaintext

msg = b'Text to be encrypted by ECC public key and ' \
      b'decrypted by its corresponding ECC private key'
print("\n\noriginal msg:", msg)

print('\n\nEncryption/Decryption using ECDH scheme Curve25519:')
start=timer()
privKey = bytes_to_int(k_b.encode())
pubKey = privKey * curve.g
encryptedMsg = encrypt_ECC(msg, pubKey)
encryptedMsgObj = {
            'ciphertext': binascii.hexlify(encryptedMsg[0]),
            'nonce': binascii.hexlify(encryptedMsg[1]),
            'authTag': binascii.hexlify(encryptedMsg[2]),
            'ciphertextPubKey': hex(encryptedMsg[3].x) + hex(encryptedMsg[3].y % 2)[2:]
}
end=timer()
print("\nTime taken to encrypt the plaintext: ", end-start)
print("\nencrypted msg:", encryptedMsgObj)
start=timer()
decryptedMsg = decrypt_ECC(encryptedMsg, privKey)
end=timer()
print("\nTime taken to decrypt the ciphertext: ", end-start)
print("\ndecrypted msg:", decryptedMsg)



